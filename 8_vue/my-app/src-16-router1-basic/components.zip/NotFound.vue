<template>
  <div class="hello">
    <h1>NotFound</h1>    
  </div>
</template>

<script>
export default {
 name: 'NotFound',
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
