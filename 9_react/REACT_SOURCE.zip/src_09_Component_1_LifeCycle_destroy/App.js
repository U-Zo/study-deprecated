import React, { Component } from "react";
import { Contact } from "./components/Contact";

class App extends Component {
  constructor() {
    super();
    this.state = { destroy: true };//컴포넌트 삭제 여부 판단 변수 
    console.log("constructor호출==============");
  }

  static getDerivedStateFromProps(props, state) {
    console.log("getDerivedStateFromProps==============");
    return {};
  }
  componentDidMount() {
    console.log("componentDidMount==============");
  }
  componentWillUnmount() {
    console.log("componentWillUnmount============");
  }
  render() {
    console.log("render호출=============");
    return <div>{this.state.destroy ? null : <Contact />}</div>;
  }
}

export default App;
