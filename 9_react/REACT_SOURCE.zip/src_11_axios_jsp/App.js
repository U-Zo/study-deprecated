import React, { Component } from 'react';
import axios from 'axios';
class App extends Component {
  mesg="홍길동";
   constructor(){
     super();
     this.handleEvent= this.handleEvent.bind(this);
     this.handleEvent2= this.handleEvent2.bind(this);
   }
   //이벤트
   handleEvent(e){
     axios.get("http://localhost:8090/AngularWeb/getPersonList.jsp").
     then((responseData)=>{
       console.log(responseData);
     }).catch((error)=> {
       console.log("error");       
     });
   }//end handleEvent




    handleEvent2(e){
      const person={
        id:'a',
        name:'a',
        age:'10'
      };
      axios.get('http://localhost:8090/AngularWeb/addPerson.jsp',
      {params:person}).then((responseData)=>{
        console.log(responseData);
      }).catch((error)=>{console.log("error")});
    }//end handleEvent2
  render() {
    return (
      <div>
        <button onClick={this.handleEvent}>보기</button>
        <button onClick={this.handleEvent2}>저장</button>
      </div>
    );
  }
}

export default App;