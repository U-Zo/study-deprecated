import React, { Component } from "react";
import Contact from "./components/Contact";

class App extends Component {
  render() {
    const persons = [
      { name: "홍길동", age: "10" },
      { name: "유관순", age: "20" },
      { name: "강감찬", age: "30" },
    ];
    const personTag = persons.map(function (row, idx) {
      return (
        <div>
          {row.name}: {row.age}
        </div>
      );
    });
    //arrow함수로 구현
  //   const personTag = persons.map((row) => {
  //     return (
  //       <div>
  //         {row.name}:{row.age}
  //       </div>
  //     );
  //   });
    return (
      <div>
        <Contact xxx="홍길동" />
        {personTag}
      </div>
    );
  }
}

export default App;
