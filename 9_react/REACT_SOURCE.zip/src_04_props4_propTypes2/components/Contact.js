import React, { Component } from "react";
import PropTypes from "prop-types"; //주의

export class Contact extends Component {
  render() {
    let name = this.props.name;
    let age = this.props.age;
    let phones = this.props.phones;
    console.log(">>>", phones);
    let isMarried = this.props.isMarried;
    console.log(">>>", isMarried);
    return (
      <div>
        <h1>{name}</h1>
        <h1>
          {this.props.age}, {age}
        </h1>
        <h1>{this.props.phones}</h1>
        <h1>{phones[0]}</h1>
        <h1>{this.props.isMarried}</h1>
        <h1>{this.props.my()}</h1>
      </div>
    );
  }
}
//클래스 아래 부분에
// 기본값 설정
Contact.defaultProps = {
  name: "유관순",
  age: 20,
};

//validate
Contact.propTypes = {
  name: PropTypes.string,
  age: PropTypes.number,
  phones: PropTypes.array,
  my: PropTypes.func,
  isMarried: PropTypes.bool,
};
