import React, { Component } from "react";

export class Contact extends Component {
  constructor() {
    super();
    this.state = {
      contactData: [
        { name: "Allen", phone: "000-000-0001" },
        { name: "Bob", phone: "000-000-0002" },
        { name: "Charli", phone: "000-000-0003" },
        { name: "David", phone: "000-000-0004" },
      ],
      username: "", //추가
      phone: "", //추가
    };
    this.handle = this.handle.bind(this);
    this.handleChange = this.handleChange.bind(this);
  } //end constructor
  handleChange(e) {//textbox이 name, value 사용 {username:'홍길동'} 저장 
    let nextState = {};
    nextState[e.target.name] = e.target.value;
    this.setState(nextState); //추가
  } //end change
  handle() {
    let xxx = this.state.contactData;
    xxx.push({ name: this.state.username, phone: this.state.phone });
    this.setState({
      contactData: xxx,
    });
  }
  render() {
    return (
      <div>
        {this.state.contactData.map(function (row, idx) {
          return (
            <div key={idx}>
              {row.name}&nbsp;&nbsp;{row.phone}
            </div>
          );
        })}
        이름
        <input
          type="text"
          name="username"
          id="kkk"
          value={this.state.name}
          onChange={this.handleChange}
        />
        <br></br>
        전화번호
        <input
          type="text"
          name="phone"
          id="kkk"
          value={this.state.phone}
          onChange={this.handleChange}
        />
        <button onClick={this.handle}>추가하기</button>
        <br></br>
      </div>
    );
  }
}

//export default Contact;
