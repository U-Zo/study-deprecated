import React, { Component } from "react";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "홍길동",
    };
    //static getDerivedStateFromProps에서 사용, 에러 메세지 없애기 위해서 선언
    console.log("constructor호출======");
    this.handleEvent = this.handleEvent.bind(this);
  }
  handleEvent() {
    this.setState({
      username: "이순신",
    });
  }
  static getDerivedStateFromProps(props, state) {
    console.log("getDerivedStateFromProps=========", props, state);
    //값의 접근은 props, state매개변수 사용, this.props, this.state안됨
    return {}; //주의
  }
  // componentWillMount() {
  //   console.log("componentWillMount==============");
  // }
  // componentWillUpdate(nextProps, nextState) {
  //   console.log("componentWillUpdate==============");
  // }
  // componentWillReceiveProps(nextProps) {
  //   console.log("componentWillReceiveProps==============");
  // }
  componentDidMount() {
    console.log("componentDidMount==============");
  }//컴포넌트 생성 완료 

  shouldComponentUpdate(nextProps, nextState) {
    //setState()함수 호출시 호출, 화면을 새로 출력할 지 말지를 결정
    console.log("shouldComponentUpdate==============");
    return true; //랜더링 계속 진행 false :진행하지 않음, true인 경우render함수 호출
  }
  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log("getSnapshotBeforeUpdate==============", prevProps, prevState);
    //변경된 화면 완성 후 호출
    return { test: "aaa" };//리턴값은 componentDidUpdate의 세번째 인자로 전달(snapShot) 
  }

  componentDidUpdate(prevProps, prevState, snapShot) {//업데이트 마지막 함수
    console.log("componentDidUpdate==============", snapShot);
  }

  componentWillUnmount() {//컴포넌트 제거시 호출 
    console.log("componentWillUnmount==============");
  }

  render() {
    console.log("render==========================");
    return (
      <div>
        username:{this.state.username}
        <br></br>
        <button onClick={this.handleEvent}>
          this.state.username값 변경하기
        </button>
      </div>
    );
  }
}

App.propTypes = {};

export default App;
