import React, { Component } from "react";

export class Counter extends Component {
  constructor() {
    super();
    this.state = {
      contactData: [
        { name: "Allen", phone: "000-000-0001" },
        { name: "Bob", phone: "000-000-0022" },
        { name: "Charlie", phone: "000-000-0333" },
        { name: "David", phone: "000-000-444" },
      ],
      username: "", //사용자 이름 저장용 변수추가
    };
    this.handle = this.handle.bind(this); //handleEvent에 state를 바인딩
    this.handleChange = this.handleChange.bind(this);
  } //end constructor
  handleChange(e) {//input에 글이 써질 때 호출 username에 이름 저장 
    //추가됨
    this.setState({
      username: e.target.value,
    }); //end setState
  } //end handleChange
  handle() {
    console.log("handle");
    let xxx = this.state.contactData;
    xxx.push({ name: this.state.username, phone: "000-0000-0005" }); //사용자 추가
    this.setState({
      contactDate: xxx,
    });
  }

  render() {
    //{this.state.변수명}랜더링
    return (
      <div>
        {this.state.contactData.map(function (row, idx) {
          return (
            <div key={idx}>
              {row.name}:{row.phone}
            </div>
          );
        })}
        {/* 사용자 이름 추가 */}
        사용자이름추가: 
        <input
          type="text"
          name="username"
          id="kkk"
          value={this.state.username}
          onChange={this.handleChange}
        ></input>
        <button onClick={this.handle}>사용자 추가</button>
         {/* 사용자 이름 추가 끝 */}
        {/* 추가된 사용자 이름 */}
        추가된 사용자이름 :{this.state.username}
        <br />
      </div>
    );
  }
}

//export default Contact;
