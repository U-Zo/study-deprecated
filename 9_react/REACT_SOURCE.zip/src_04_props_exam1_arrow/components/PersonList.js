import React, { Component } from "react";

export class PersonList extends Component {
  persons; //this키로 접근
  render() {
    this.persons = this.props.xxx; //파싱
    var xxx = this.persons.map(function (row, idx) {
      return (
        <tr key={idx}>
          <td>{idx + 1}</td>
          <td>{row.name}</td>
          <td>{row.age}</td>
        </tr>
      );
    }); //end xxx
    console.log(xxx);
    /////////////////////////////
    var xxx2 = this.persons.map((row, idx) => {
      return (
        <tr key={idx}>
          <td>{idx + 1}</td>
          <td>{row.name}</td>
          <td>{row.age}</td>
        </tr>
      );
    }); //end xxx2
    console.log(xxx2);
    ////////////실제 return
    return (
      //div없음
      <tbody>
        {xxx}
        {xxx2}
      </tbody>
    );
  } //end render
}

//export default PersonList;
