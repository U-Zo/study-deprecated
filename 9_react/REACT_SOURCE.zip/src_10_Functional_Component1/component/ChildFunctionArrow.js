import React from 'react';//{Component삭제}
//화살표함수의 사용
const ChildFunctionArrow=(props)=>{
    return (
        <div>
            <h1>함수형 Arrow 컴포넌트(Function Arrow Component)  </h1>
            props:{props.mesg}
        </div>
    )
}
export default ChildFunctionArrow;