import React from 'react';//{Component삭제}
//화살표함수의 사용
const ChildDestructuring=({mesg})=>{
    return (
        <div>
            <h1>함수형 컴포넌트(Function Component) Destructring </h1>
            props:{mesg}
        </div>
    )
}
export default ChildDestructuring;