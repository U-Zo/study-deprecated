import React from 'react';//{Component삭제}

export default function ChildFucntion(props){
    
    return(
        <div>
            <h1>함수형 컴포넌트(Fuction Component)2</h1>
            props:{props.mesg}
        </div>
    )
}