import React, { Component } from 'react';
export class ChildComponent extends Component {
    render() {
        let mesg= this.props.mesg;
        return (
            <div>
                <h1>클래스  컴포넌트(Class Component)</h1>
                props:{this.props.mesg}<br></br>
                props:{mesg}<br/>
            </div>
        );
    }
}

