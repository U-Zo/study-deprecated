import React, { Component } from 'react';
import {BrowserRouter as Router,Route} from 'react-router-dom';
import Home from './component/Home';
import Member from './component/Member';
import Login from './component/Login';
class App extends Component {
  render() {
    return (
      <div>
        <Router>
          <div>
            <Route exact path='/' component={Home}/>
            <Route exact path='/member' component={Member}/>
            <Route exact path='/login' component={Login}/>
          </div>
        </Router>
      </div>
    );
  }
}

export default App;