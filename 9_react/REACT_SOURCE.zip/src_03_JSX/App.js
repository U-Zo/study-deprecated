import React, { Component } from "react";
import {
  Contact,
  Contact2,
  Contact21,
  Contact3,
  Contact4,
  Contact5,
  Contact6,
  Contact7,
  Contact8,
} from "./components/Contact";
//1. 컴포넌트 import
class App extends Component {
  render() {
    return (
      <div>
        <h1>AppComponent</h1>
        <br></br>
        <Contact />
        <Contact2 />
        <Contact21 />
        <Contact3 />
        <Contact4 />
        <Contact5 />
        <Contact6 />
        <Contact7 />
        <Contact8 />
      </div>
    );
  }
}

export default App;
