import React, { Component } from "react";
import "./Contact.css"; //css임포트
/*export와 export default의 차이
1. export Default는 모듈에서 반드시 하나만 사용
import 시 import Contact from './Contact"
2. export는 모듈에서 여러번 사용가능
import {Contact, Contact2} from './Contact" 
*/
//1. JSX에서 변수값 사용시 {} 이용, 반드시  root태그가 있어야 하며
//""사용안함
//rcc
export class Contact extends Component {
  render() {
    let mesg = "world";
    //화면에 구현 부분 template
    return (
      <div>
        <h1>
          {mesg}&nbsp;{100}
          {"Hello"}
        </h1>
      </div>
    );
  }
} //end class

//2.JSX에서 자바스크립트 사용시 {}이용
export class Contact2 extends Component {
  render() {
    let myArr = ["A", "B", "C"];
    return (
      <div>
        <ul>
          {
            //자바스크립트 코드를 사용하기 위해서 {}사용
            myArr.map(function (row, idx) {
              console.log(row, "\t", idx);
              return <li key={idx}>{row}</li>;
            })
          }
        </ul>
      </div>
    );
  }
}
//export default Contact;
//2-1자바스크립트 코드가 render 밖에 있기 때문에 다양한 작업이 가능
var myArr = ["D", "E", "F"]; //메소드 밖에 선언
function my() {
  return myArr.map(function (row, idx) {
    return <li key={idx}>{row}</li>;
  });
}
export class Contact21 extends Component {
  render() {
    return (
      <div>
        <ul>
          {
            //자바스크립트 코드 사용시 {}사용
            my()
          }
        </ul>
      </div>
    );
  }
}
/////////////////////////
//3.jsx에서 spread 연산자의 사용
export class Contact3 extends Component {
  render() {
    //변수 선언
    var attr = {
      href: "https://www.daum.net",
      target: "_blank",
    };
    return (
      <div>
        <a {...attr}>daum: {attr.href}</a>
      </div>
    );
  }
}
///////////////////////////
//4. jsx에서 사용하는 multi node사용의 예
export class Contact4 extends Component {
  render() {
    //변수 선언
    var multi = [<span key="_1">Hello</span>, <span key="_2">Hello</span>];
    //유니크 key사용
    return <div>{multi}</div>;
  }
} //end class
//////////////////////////////////
//5. jsx에서는 이벤트 처리시 camel 표기법 필수
function myok() {//클래스 밖에선언 
  //this키 없이 사용
  console.log("myOk");
}
export class Contact5 extends Component {
  //메서드 선언
  myok2() {//클래스 안에 선언 
    //this키로 접근
    console.log("myOk2");
  }//end myok2
  render() {
    return (
      <div>
        {/* 이벤트처리시 카멜 표기법 준수 */}
        <button onClick={myok}>myOk</button>&nbsp;
        <button onClick={this.myok2}>myOk2</button>
      </div>
    );
  }
} //end class
//////////////////////////
//6. jsx에서 css는 className, label은 htmlFor 형식으로 사용
export class Contact6 extends Component {
  render() {
    return (
      <div>
        <p className="xyz">hello-css 적용됨</p>
        <label htmlFor="myInput"> hello2</label>
        <input type="text" name="myInput"></input>
      </div>
    );
  }
} //end class
/////////////////////////////////////
//7. jsx에서는 style이 객체로 처리됨
//backgroundColor
//fontSize, textAlignt 같은 카멜표기법 사용
export class Contact7 extends Component {
  render() {
    var myStyle = { fontSize: "50px", background: "yellow" };
    return (
      <div>
        <p style={myStyle}>myStyle적용됨1</p>
        <p style={{ fontSize: "20px", background: "red" }}>myStyle적용됨2</p>
      </div>
    );
  }
} //end class
/////////////////////////////////////////////
//8.jsx주석은 {/* */}형식으로 사용,
//반드시 container root태그 안에서 사용하여야함
export class Contact8 extends Component {
  render() {
    //root태그 밖의 주석
    var myStyle = { fontSize: "50px", background: "yellow" };
    return (
      <div>
        {/* 이것은 주석입니다. */}
        <p style={myStyle}>myStyle적용됨1</p>
        <p style={{ fontSize: "20px", background: "red" }}>myStyle적용됨2</p>
      </div>
    );
  }
}
