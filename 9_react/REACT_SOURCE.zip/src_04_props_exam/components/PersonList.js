import React, { Component } from "react";

export class PersonList extends Component {
  persons; //this키로 접근
  render() {
    this.persons = this.props.xxx; //파싱
    console.log(this.persons);
    return (
      //div생략
      <tbody>
        {this.persons.map(function (row, idx) {
          return (
            <tr key={idx}>
              <td>{idx + 1}</td>
              <td>{row.name}</td>
              <td>{row.age}</td>
            </tr>
          );
        })}
      </tbody>
    );
  }//end render 
}//end class

//export default PersonList;
