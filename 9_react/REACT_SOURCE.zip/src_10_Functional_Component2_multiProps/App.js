import React, { Component } from 'react';
import {ChildComponent} from './component/ChildComponent';
import ChildFucntion from './component/ChildFucntion'
import ChildFunctionArrow from './component/ChildFunctionArrow';
import ChildDestructuring from './component/ChildDestructuring';

class App extends Component {
  render() {
    return (
      <div>
        <ChildComponent mesg="ChildComponent 전송"  mesg2="100"/>
        <ChildFucntion mesg="ChildFunction 전송" mesg2="100"/>
        <ChildFunctionArrow mesg="ChildFunctionArrow 전송" mesg2="100"/>
        <ChildDestructuring mesg="ChildDestructuring 전송" mesg2="100"/>
      </div>
    );
  }
}

export default App;