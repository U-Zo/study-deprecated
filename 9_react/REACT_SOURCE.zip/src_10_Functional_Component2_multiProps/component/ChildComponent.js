import React, { Component } from 'react';
export class ChildComponent extends Component {
    render() {
        let {mesg, mesg2}= this.props;
        return (
            <div>
                <h1>함수형 컴포넌트(Fuctional Component)</h1>
                props:{mesg}<br></br>
                props2:{mesg2}<br/>
            </div>
        );
    }
}

