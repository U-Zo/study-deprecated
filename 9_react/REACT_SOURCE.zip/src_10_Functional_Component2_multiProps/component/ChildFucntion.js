import React from 'react';//{Component삭제}

export default function ChildFucntion(props){
    const {mesg, mesg2}= props;
    return(
        <div>
            <h1>함수형 컴포넌트(Fuction Component)2</h1>
                props:{mesg}<br></br>
                props2:{mesg2}<br/>
        </div>
    )
}