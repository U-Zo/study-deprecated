import React, { Component } from "react";
import { MemberList } from "./MemberList";

export class Member extends Component {
  constructor() {
    super();
    this.state = {
      memberData: [],
      username: "",
      age: "",
      address: "",
    };
    //바인딩
    this.handleChange = this.handleChange.bind(this);
    this.addMember = this.addMember.bind(this);
    //xyz함수는 직접 호출
  }
  render() {
    return (
      <div>
        이름
        <input
          type="text"
          name="username"
          value={this.state.username}
          onChange={this.handleChange}
        />
        나이
        <input
          type="text"
          name="age"
          value={this.state.age}
          onChange={this.handleChange}
        />
        주소
        <input
          type="text"
          name="address"
          value={this.state.address}
          onChange={this.handleChange}
        />
        <button onClick={this.addMember}>저장</button>
        <button onClick={this.xyz.bind(this, "홍길동")}>xyz함수 호출</button>
        <MemberList memberData={this.state.memberData} />
      </div>
    );
  } //end render
  handleChange(e) {//텍스트 박스 한 항목을 state에 {key:value}로 저장 
    let nextState = {};
    nextState[e.target.name] = e.target.value;
    this.setState(nextState);
  }
  //////////////
  addMember() {
    console.log(this.state.memberData);
    let xxx = this.state.memberData;
    xxx.push({  //handleChange에서 저장한 state.변수 를 배열에 push
      username: this.state.username,
      age: this.state.age,
      address: this.state.address,
    });
    this.setState({
      memberData: xxx,
    });
  } //end
  xyz(e) {
    console.log("xyz()===================", e);
  }
} //end class

//export default Contact;
