import React, { Component } from "react";

export class ChildComponent extends Component {
  constructor() {
    super();
    this.submit = this.submit.bind(this); //바인딩 주의
  }
  render() {
    //div없음
    return (
      <form onSubmit={this.submit}>
        아이디
        <input type="text" ref="userid" />
        비밀번호
        {/* ref값으로 콜백함수 지정가능 태그자체를 this.passwd변수에 저장 */}
        <input
          type="text"
          ref={(x) => {
            console.log("x", x);
            this.passwd = x;
          }}
        />
        <button>로그인</button>
      </form>
    );
  } //end render
  submit(e) {
    e.preventDefault(); //return false 지원안함
    console.log("submit", this.refs);
    console.log("submit this.passwd=====", this.passwd);
    //this.passwd는 dom자체가 됨
    //input태그의 ref값을 this.refs로 참조함
    const { userid } = this.refs; //passwd생략
    userid.value = "AAAAAAAA";
    userid.focus();
    console.log(userid.value + "\t" + this.passwd.value);
  }
}

//export default Contact;
