import React, { Component } from "react";

export class Contact extends Component {
  render() {
    let { mesg: a, mesg2: b } = this.props;
    return (
      <div>
        <h1>{a}</h1>
        <h1>{b}</h1>
      </div>
    );
  }
}//end class 
//클래스바깥에서 기본값 클래스명.defaultProps설정
Contact.defaultProps = {
  mesg: "유관순",
  mesg2: 200,
};
//export default Contact;
