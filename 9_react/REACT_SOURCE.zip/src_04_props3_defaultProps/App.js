import React, { Component } from "react";
import { Contact } from "./components/Contact";

class App extends Component {
  render() {
    return (
      <div>
        Hello World
        <Contact mesg="홍길동" mesg2="10" />
        <Contact /> {/* 넘기는 props 데이터 없음 */}       
      </div>
    );
  }
}

export default App;
