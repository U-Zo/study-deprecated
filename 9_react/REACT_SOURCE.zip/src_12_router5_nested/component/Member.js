import React from 'react';
//npm install query-string
import queryString from 'query-string';

// class Member extends Component {
//     render() {
//         console.log(this.props.match);
//         console.log(this.props.history);
//         console.log(this.props.location);
//         return (
//             <div>
//                 <h1>Member</h1>
//             </div>
//         );
//     }
// }
const Member=({match, history, location})=>{
            console.log("match", match);
            console.log("history", history);
            console.log("locaiton", location);

            // const query= queryString.parse(location.search);
            // console.log("query>>>>>>", query);
            return (
                <div>
                    <h1>Member</h1>
                    params: {match.params.id} 입니다.<br/>
                    {/* queryString: {query.xxx} */}
                </div>
            );
}
export default Member;