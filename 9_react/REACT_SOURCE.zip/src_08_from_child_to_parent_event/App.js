import React, { Component } from "react";
import { Child } from "./components/Child";
import { Child2 } from "./components/Child2";

class App extends Component {
  mesg = "홍길동";
  constructor() {
    super();
    this.handleEvent = this.handleEvent.bind(this);
  }
  handleEvent(e) {
    console.log("App.handleEvent=================", e);
  }
  render() {
    return (
      <div>
        <Child mesg={this.mesg} />
        {/* 자식에게 부모 함수 전달  */}
        <Child2 mesg={this.mesg} onEvent={this.handleEvent} />
      </div>
    );
  }
}

export default App;
