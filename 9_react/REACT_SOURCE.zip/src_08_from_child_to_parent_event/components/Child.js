import React, { Component } from "react";

export class Child extends Component {
  mesg;
  constructor() {
    super();
    this.handleEvent = this.handleEvent.bind(this);
  }
  //이벤트
  handleEvent() {
    console.log("Child.handleEvent===================");
  }
  render() {
    this.mesg = this.props.mesg;
    return (
      <div>
        <h1>child component</h1>
        <h1>{this.mesg}</h1>
        <button onClick={this.handleEvent}>OK</button>
      </div>
    );
  }
}

//export default Contact;
