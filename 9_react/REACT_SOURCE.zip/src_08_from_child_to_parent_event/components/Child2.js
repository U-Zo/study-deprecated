import React, { Component } from "react";

export class Child2 extends Component {
  render() {
    //객체 destructuring
    const { mesg, onEvent } = this.props; //데이터와 부모의 함수를 받아옴
    //let xxx= this.props.onEvent
    var p = { username: "홍길동", age: 20 };
    console.log("onEvent()====", onEvent);
    return (
      //onClick={onEvent}는 부모의 함수를 부르지 못함, 부모의 함수를 호출해야함
      //리엑트 초심자가 할 수 있는 실수 임. 이렇게 코딩하면 해당함수가
      //랜더링 될때 호출이됨
      <div>
        <h1>child2 Component</h1>
        <h1>{mesg}</h1>
        <button
          onClick={() => {
            onEvent();//부모의 함수 호출
          }}
        >
          ok1 arrow
        </button>
        <br></br>
        <button
          onClick={() => {
            onEvent(p);//부모함수 호출, 데이터 전달
          }}
        >
          ok2 arrow p 데이터 전달
        </button>
        <br></br>
        <button onClick={onEvent()}>onEvent()</button>
        <br></br>
      </div>
    );
  }
}

//export default Contact;
