import React, { Component } from "react";
import { CardPanel } from "./components/CardPanel";

class App extends Component {
  render() {
    return (
      <div>
        <CardPanel kkk={111} />
      </div>
    );
  }
}

export default App;
