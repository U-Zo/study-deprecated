import React, { Component } from "react";

export class Card extends Component {
  //1. 생성자
  constructor() {
    super();
    console.log("Card.constructor props============", this.props);
    this.state = { cardNum: 0 };
  } //end
  ///////////////////// life cycle오버라이딩 시작
  static getDerivedStateFromProps(props, state) {
    //static주의
    console.log("Card.getDerivedStateFromProps.props============", props);
    console.log(
      "Card.getDerivedStateFromProps.state============",  state);
    return {}; //리턴이 필요함
  }
  componentDidMount() {
    console.log("Card.componentDidMount++++++++, 랜더링 된 후 ");
  }
  //   componentWillMount() {
  //     console.log("Card.componentWillMount+++++++++,랜더링되기전");
  //   } //end
  render() {
    return (
      <div>
        <h1>Card Component</h1>
      </div>
    );
  }
}
