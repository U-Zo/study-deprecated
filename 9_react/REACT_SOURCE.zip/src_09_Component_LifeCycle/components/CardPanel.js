import React, { Component } from "react";
import { Card } from "./Card";

export class CardPanel extends Component {
  //1.생성자
  constructor() {
    super();
    console.log("CardPanel.constructor props", this.props);
    this.state = {
      cardPanelNum: 0,
    };
  } //end
  componentWillMount() {
    console.log("CardPanel.componentWillMount+++++++++,랜더링되기전");
  } //end
  componentDidMount() {
    console.log("CardPanel.componentDidMount++++++++, 랜더링 된 후 ");
  }
  render() {
    return (
      <div>
        <h1>CardPanel component</h1>
        <Card xx={10} />
      </div>
    );
  }
}

//export default Contact;
