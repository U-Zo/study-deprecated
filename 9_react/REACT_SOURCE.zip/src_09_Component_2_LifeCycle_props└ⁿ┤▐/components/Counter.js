import React, { Component } from "react";
//rcfc로 실행 export
export class Counter extends Component {
  constructor(props) {
    super(props);
    console.log("Counter.constructor==========", props.xxx);
    this.state = { num: props.xxx };//0
    this.handleClick = this.handleClick.bind(this);
  } //end
  /////////////이벤트 처리
  handleClick() {
    this.setState({
      num: this.state.num + 1,
    });
  }
  ////////////////life cycle오버라이딩
  componentWillMount() {}
  componentDidMount() {}
  componentWillReceiveProps(nextProps) {}
  shouldComponentUpdate(nextProps, nextState) {
    console.log(
      "Counter.shouldComponentUpdate=====컴포넌트를 수정할지 결정중....."
    );
    console.log("Counter.shouldComponentUpdate.nextProps=====", nextProps);
    console.log("Counter.shouldComponentUpdate.nextState=====", nextState);
    if (nextState.num === 4) {
      return true; //return  true이면 화면 갱신
    } else {
      return false; //return false 이면 화면 갱신 안함
    }
  } //end
  /////////////////////
  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log(
      "Counter.getSnapshotBeforeUpdate====컴포넌트가 리렌더링 후 바로 호출됨....."
    );
    console.log("Counter.getSnapshotBeforeUpdate.prevProps=====", prevProps);
    console.log("Counter.getSnapshotBeforeUpdate.prevState=====", prevState);
    return { aa: 300 }; //componentDidUpdate의 세번째 인자가 받게 됨
  }

  componentWillUpdate() {}

  componentDidUpdate(prevProps, prevState, snapShot) {
    console.log(
      "Counter.componentDidUpdate====컴포넌트가 리렌더링 완료 된 후  호출됨....."
    );
    console.log("Counter.componentDidUpdate.prevProps=====", prevProps);
    console.log("Counter.componentDidUpdate.prevState=====", prevState);
    console.log("Counter.componentDidUpdate.snapShot=====", snapShot);
  }

  componentWillUnmount() {}

  render() {
    return (
      <div>
        <h2>{this.state.num}</h2>
        <button onClick={this.handleClick}>press me</button>
      </div>
    );
  }
}

Counter.propTypes = {};

//export default Counter;
