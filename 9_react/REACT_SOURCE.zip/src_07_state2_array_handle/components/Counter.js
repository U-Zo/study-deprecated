import React, { Component } from "react";

export class Counter extends Component {
  constructor() {
    super();
    this.state = {
      contactData: [
        { name: "Allen", phone: "000-000-0001" },
        { name: "Bob", phone: "000-000-0022" },
        { name: "Charlie", phone: "000-000-0333" },
        { name: "David", phone: "000-000-444" },
      ],//end contactData
    };//end state
    this.handle = this.handle.bind(this); //handleEvent에 state를 바인딩
  } //end constructor

  handle() {
    console.log("handle()=====================");
    let xxx = this.state.contactData; //contactData저장
    xxx.push({ name: "David", phone: "000-0000-0005" }); //사용자 추가
    this.setState({
      contactData: xxx,
    }); //end setState
  }

// handle 함수
// 변수에 contactData저장
//저장된 변수에 push({새로운 사람})
//this.setState()사용 contactData변경 

  render() {
    //{this.state.변수명}랜더링
    return (
      <div>
        {this.state.contactData.map(function (row, idx) {
          return (
            <div key={idx}>
              {row.name}:{row.phone}
            </div>
          );
        })}     
           <button onClick={this.handle}>사용자 추가</button>
      </div>
    );
  }
}

//export default Contact;
