import React, { Component } from "react";
import PropTypes from "prop-types"; //주의

export class Contact extends Component {
  static defaultProps = {
    //기본값
    mesg: "유관순",
    mesg2: 20,
  };
  static propTypes = {
    //타입검사
    mesg: PropTypes.string,
    mesg2: PropTypes.number,
  };
  render() {
    let mesg = this.props.mesg;
    return (
      <div>
        <h1>{mesg}</h1>
        <h1>{this.props.mesg2}</h1>
      </div>
    );
  }
}

//export default Contact;
