import React, { Component } from "react";

export class Child extends Component {
  render() {
    return (
      <div>
        {/* 이벤트 카멜표기법 */}
        <button onClick={this.handleEvent}>handleEvent</button>
        <br></br>
        <button onClick={this.handleEvent2}>handleEvent2</button>
        <br></br>
        <a href="http://www.daum.net" onClick={this.handlEvent3}>
          handleEvent3
        </a>
        <br></br>
        <button onClick={() => this.a()}>a()</button>
        <br></br>
        <button onClick={(e) => this.b(e, 100)}>b()</button>
      </div>
    );
  } //end render
  a() {
    console.log("a===========");
  }
  b(x, y) {
    console.log("b===========", x, y);
  }
  handleEvent() {
    console.log("handleEvent===============");
  }
  handleEvent2(e) {
    console.log("handleEvent2===========", e); //event출력
  }
  handlEvent3(e) {
    console.log("handlEvent3=============preventDefault");
    e.preventDefault(); //
    //return false 지원안됨
  }
}

//이벤트처리함수 작성

//export default Contact;
