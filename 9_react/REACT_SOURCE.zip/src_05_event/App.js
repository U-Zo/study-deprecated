import React, { Component } from "react";
import { Child } from "./components/Child";

class App extends Component {
  render() {
    return (
      <div>
        <Child />
      </div>
    );
  }
}

export default App;
