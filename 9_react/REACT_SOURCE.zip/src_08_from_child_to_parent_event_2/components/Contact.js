import React, { Component } from "react";
import PropTypes from "prop-types";

export class Contact extends Component {
  render() {
    const xxx = this.props.onAdd;
    return (
      <div>
        Contact 현재 카운트 : {this.props.count}
        <br></br>
        <button onClick={() => this.props.onAdd()}>카운트증가1</button>
        <br></br>
        {/* 넘겨져온 함수 호출  */}
        <button onClick={()=>xxx()}>카운트증가2</button>
        <br></br>
        {/* 넘겨져온 함수 호출  */}
      </div>
    );
  }
}
Contact.propTypes = {
  count: PropTypes.number,
  onAdd: PropTypes.func,
};
