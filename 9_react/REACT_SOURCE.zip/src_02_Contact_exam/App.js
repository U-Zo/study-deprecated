import React, { Component } from "react";
import { Contact } from "./components/Contact";
//1. 컴포넌트 import
class App extends Component {
  render() {
    return (
      <div>
        <h1>AppComponent</h1>
        <br></br>
        <Contact />
        {/* 2. 컴포넌트 include  */}
      </div>
    );
  }
}

export default App;
