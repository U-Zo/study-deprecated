import React, { Component } from "react";
import { ContactList } from "./ContactList";

export class Contact extends Component {
  render() {
    //화면에 구현 부분 template
    return (
      <div>
        <h1>Contacts 홈페이지</h1>
        <ContactList />
      </div>
    );
  }
}
