import React, { Component } from "react";

export class ContactList extends Component {
  //export 로 수정  ,,Contact.js에서 import 사용, App.js에서 보여지게함
  render() {
    //template부분
    return (
      <div>
        <ul>
          <li>홍길동</li>
          <li>이순신</li>
          <li>유관순</li>
          <li>강감찬</li>
        </ul>
      </div>
    );
  }
}
