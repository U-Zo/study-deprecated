import React, { Component } from "react";

export class Contact extends Component {
  render() {
    //화면에 구현 부분 template
    return <div>Concat component</div>;
  }
}
//export default Contact;  //생략 export class로 변경
export class Contact2 extends Component {
  info() {
    return <h2> Contatct2 Component</h2>; //""없이 사용
  }
  render() {
    return this.info();
  }
}

//export default Contact;
