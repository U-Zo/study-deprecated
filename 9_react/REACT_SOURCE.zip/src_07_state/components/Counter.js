import React, { Component } from "react";

export class Counter extends Component {
  constructor() {//1.생성자 작성, super(), this.state, 이벤트처리함수에  .bind(this)
    super();
    this.state = {//state 변수 선언 및 초기화 
      xyz: 0,
      number: 100,
    };
    this.handleClick = this.handleClick.bind(this); //handleEvent에 this(state)를 바인딩
  } //end constructor


  handleClick() {
    console.log("handleClick()=====================");
    this.setState({//state값 변경시 this.setState({})을 반드시 이용 
      xyz: this.state.xyz + 1, //기존값(this.state.키) 접근  1 증가 this.setState함수 사용 업데이트
    }); //end setState
  }

  render() {
    //{this.state.변수명}랜더링
    return (
      <div>
        <h2>{this.state.xyz}</h2>
        <p>{this.state.number}</p>
        <button onClick={this.handleClick}>xyz값 증가</button>
      </div>
    );
  }
}

//export default Contact;
