import React, { Component } from "react";

class App extends Component {
  constructor() {
    super();
    this.state = {
      count: 0,
    };
    this.handleEvent = this.handleEvent.bind(this);//바인딩
    this.reset = this.reset.bind(this);//바인딩
  }
  handleEvent() {
    this.setState(({ count }) => ({ count: count + 1 }));
  } //end
  reset() {
    this.setState({ count: 0 });
  }

  render() {
    return (
      <div>
        <h1>현재 카운트 {this.state.count}</h1>
        <button onClick={this.handleEvent} onMouseOut={this.reset}>
          버튼 밖으로 커서가 움직이면 0으로 초기화 됩니다.
        </button>
      </div>
    );
  }
}

export default App;
