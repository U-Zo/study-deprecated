import React, { Component } from "react";

export class Person extends Component {
  person; //this키로 접근
  render() {
    this.person = this.props.yyy;//한명 정보 파싱 
    return (
      <tr key={this.props.yyy2}>
        <td>{this.props.yyy2 + 1}</td>
        <td>{this.person.name}</td>
        <td>{this.person.age}</td>
      </tr>
    );
  } //end render
}

//export default Person;
