import React, { Component } from 'react';

class NoMatch extends Component {
    render() {
        return (
            <div>
                <h1>NoMathch</h1>
            </div>
        );
    }
}

export default NoMatch;