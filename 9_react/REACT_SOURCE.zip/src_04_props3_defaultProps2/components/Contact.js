import React, { Component } from "react";

export class Contact extends Component {
  //클래스안에서 static defaultProps설정
  static defaultProps = {
    mesg: "유관순",
    mesg2: 200,
  };
  render() {
    let { mesg: a, mesg2: b } = this.props;
    return (
      <div>
        <h1>{a}</h1>
        <h1>{b}</h1>
      </div>
    );
  }
}//end class

//export default Contact;
