import React, { Component } from 'react';
import {BrowserRouter as Router,Route, Switch} from 'react-router-dom';
import Home from './component/Home';
import Member from './component/Member';
import Login from './component/Login';
import NoMatch from './component/NoMatch';
import Navi from './navi/Navi'
import MyPage from './component/MyPage'
class App extends Component {
  render() {
    return (
      <div>
        <Router>
      
          <div>
            <ul>
              {/* 네비게이션 외부파일로 */}
             <Navi/>
            </ul>
            <hr/>
            <div>
              {/* switch 없으면 NoMatch는 항상 출력됨, switch는 일치하는 첫번째만 랜더링함 */}
              <Switch>
                <Route exact path='/' component={Home}/>
                <Route exact path='/member' component={Member}/>
                <Route exact path='/member/:id' component={Member}/>   {/*  */}
                <Route exact path='/login' component={Login}/>
                <Route exact path='/mypage' component={MyPage}/>
                <Route component={NoMatch}/>
              </Switch>
            </div>
          </div>
        </Router>
      </div>
    );
  }
}

export default App;