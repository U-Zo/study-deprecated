import React, { Component } from "react";

export class Counter extends Component {
  //아래 생성자의 this.state와  동일한 기능
  state = { num: 0 };
  //arrow함수를 사용하면 생성자에서 bind필요없음
  handleClick = () => {
    this.setState({
      num: this.state.num + 1, //1씩 증가
    });
  };

  // constructor() {
  //   super();
  //   this.state = {
  //     xyz: 0,
  //   };
  //   this.handleClick = this.handleClick.bind(this); //handleEvent에 state를 바인딩
  // } //end constructor
  // handleClick() {
  //   console.log("handleClick()=====================");
  //   //다음은 기존 this.state에 새로운 변수가 병합(merge)형태로 설정됨
  //   this.setState({
  //     xyz: this.state.xyz + 1, //기존값을 1 증가 this.setState함수 사용
  //     userid: "홍길동", //userid가 추가 병합됨
  //   }); //end setState
  // }

  render() {
    //{this.state.변수명}랜더링
    return (
      <div>
        <h1>{this.state.num}</h1>
        <button onClick={this.handleClick}>num값 증가</button>
      </div>
    );
  }//end render
  
}

//export default Contact;
