import React, { Component } from 'react';
import {BrowserRouter as Router,Route, Link, Switch} from 'react-router-dom';
import Home from './component/Home';
import Member from './component/Member';
import Login from './component/Login';
import NoMatch from './component/NoMatch';
class App extends Component {
  render() {
    return (
      <div>
        <Router>
         
          <div>
            <ul>
              <li>
                  <Link to='/'>Home</Link>
              </li>
              <li>
                  <Link to='/member'>Member</Link>
              </li>
              <li>
                  <Link to='/login'>Login</Link>
              </li>
            </ul>
            <hr/>
            <div>
              {/* switch 없으면 NoMatch는 항상 출력됨, switch는 일치하는 첫번째만 랜더링함 */}
              <Switch>
                <Route exact path='/' component={Home}/>
                <Route exact path='/member' component={Member}/>
                <Route exact path='/login' component={Login}/>
                <Route component={NoMatch}/>
              </Switch>
            </div>
          </div>
        </Router>
      </div>
    );
  }
}

export default App;