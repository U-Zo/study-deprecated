import React, { Component } from "react";

export class Third extends Component {
  render() {
    return (
      <div>
        <h1>{this.props.id}</h1>
        <h1>{this.props.pw}</h1>
      </div>
    );
  }
}
