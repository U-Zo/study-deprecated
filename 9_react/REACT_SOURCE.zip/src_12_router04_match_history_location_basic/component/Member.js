import React from 'react';
// class Member extends Component {
//     render() {
//         console.log(this.props.match);
//         console.log(this.props.history);
//         console.log(this.props.location);
//         return (
//             <div>
//                 <h1>Member</h1>
//             </div>
//         );
//     }
// }
const Member=({match, history, location})=>{
            console.log("match", match);
            console.log("history", history);
            console.log("locaiton", location);
            return (
                <div>
                    <h1>Member</h1>
                </div>
            );
}
export default Member;