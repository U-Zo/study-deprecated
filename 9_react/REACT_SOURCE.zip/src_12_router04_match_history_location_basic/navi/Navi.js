import React, { Component } from 'react';
import {Link, NavLink} from 'react-router-dom';

class Navi extends Component {
    render() {
        return (
            <div>
                <ul>
                    <li>
                        <Link to='/'>Home</Link>
                    </li>
                    <li>
                        <Link to='/member'>Member</Link>
                    </li>
                    <li>
                        <Link to='/login'>Login</Link>
                    </li>
                </ul>
                <NavLink to='/'>Home</NavLink>&nbsp;&nbsp;
                <NavLink to='/login'>login</NavLink>&nbsp;&nbsp;
                <NavLink to='/member'>member</NavLink>
            </div>
        );
    }
}

export default Navi;